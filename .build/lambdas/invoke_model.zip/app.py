import boto3

def lambda_handler(event, context):
    prompt = event['prompt']
    bucket = event['bucket']
    return {'prompt' : prompt, 'bucket' : bucket}